﻿using ESRI.ArcGIS.Geodatabase;
using ESRI.ArcGIS.Geometry;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace globetech.arcgis.core
{
    public class ArcGeodatabase
    {
        public class GISGeodatabase
        {
            private IFeatureWorkspace _pFeatureWorkspace = null;

            public GISGeodatabase(string path)
            {
                try
                {
                    GISWorkspace workspace = new GISWorkspace();
                    IWorkspace pWorkspace = workspace.FileGdbWorkspaceFromPropertySet(path);
                    _pFeatureWorkspace = pWorkspace as IFeatureWorkspace;
                }
                catch (Exception ex) { }
            }

            public IFeatureClass OpenFeatureclass(string fClassName)
            {
                try
                {
                    if (_pFeatureWorkspace == null) return null;
                    return _pFeatureWorkspace.OpenFeatureClass(fClassName);
                }
                catch (Exception ex) { return null; }
                finally { }
            }

            public void SpatialSearch(ref DataTable table, string fClassName, string streamFielsName, string whereClass, List<object> geometry)
            {
                IFeatureCursor pFCursor = null;

                try
                {
                    GISGeoFunction geoFunc = new GISGeoFunction();

                    if (_pFeatureWorkspace == null) return;

                    IFeatureClass pFeatureClass = _pFeatureWorkspace.OpenFeatureClass(fClassName);
                    IGeometry geo = geoFunc.UnionGeometry(geometry);
                    pFCursor = geoFunc.SpatialFilterSearch(pFeatureClass, geo, string.Empty);

                    string[] fields = FindFieldExist(streamFielsName, pFeatureClass);

                    IFeature pFeature = pFCursor.NextFeature();

                    while (pFeature != null)
                    {
                        DataRow row = table.NewRow();

                        foreach (string col in fields)
                        {
                            row[col] = pFeature.get_Value(pFeature.Fields.FindField(col));
                        }

                        table.Rows.Add(row);
                        pFeature = pFCursor.NextFeature();
                    }
                }
                catch (Exception ex) { throw ex; }
                finally
                {
                    if (pFCursor != null) System.Runtime.InteropServices.Marshal.ReleaseComObject(pFCursor);
                }
            }
            public void SpatialSearch(ref DataTable table, IFeatureClass pFeatureClassObj, string streamFielsName, string whereClass, List<object> geometry)
            {
                IFeatureCursor pFCursor = null;

                try
                {
                    IFeatureClass pFeatureClass = pFeatureClassObj as IFeatureClass;
                    GISGeoFunction geoFunc = new GISGeoFunction();
                    IGeometry geo = geoFunc.UnionGeometry(geometry);
                    pFCursor = geoFunc.SpatialFilterSearch(pFeatureClass, geo, string.Empty);

                    string[] fields = FindFieldExist(streamFielsName, pFeatureClass);

                    IFeature pFeature = pFCursor.NextFeature();

                    while (pFeature != null)
                    {
                        DataRow row = table.NewRow();

                        foreach (string col in fields)
                        {
                            row[col] = pFeature.get_Value(pFeature.Fields.FindField(col));
                        }

                        table.Rows.Add(row);
                        pFeature = pFCursor.NextFeature();
                    }
                }
                catch (Exception ex) { throw ex; }
                finally
                {
                    if (pFCursor != null) System.Runtime.InteropServices.Marshal.ReleaseComObject(pFCursor);
                }
            }

            /// <summary>
            /// Spatial Query Search. (Fix Structure.)
            /// </summary>
            /// <param name="table">Return output follow table sturcture.</param>
            /// <param name="fClassName">Feature Class for get data by spatial.</param>
            /// <param name="streamFielsName">Separate streamFielsName by ',' : example "fieldName01,fieldName02,fieldName03"</param>
            /// <param name="whereClass">Condition for get Spatial Query.</param>
            /// <param name="geometry">List of object (IGeometry).</param>
            /// <param name="setValueToIndexField0">Spatial value set in field index 0, identify by position of streamFieldsName has been spited.</param>
            /// <param name="setValueToIndexField1">Spatial value set in field index 1, identify by position of streamFieldsName has been spited.</param>
            public void SpatialSearchAndSetKeyIndex(ref DataTable table, string fClassName, string streamFielsName, string whereClass, List<object> geometry, string setValueToIndexField0, string setValueToIndexField1)
            {
                IFeatureCursor pFCursor = null;

                try
                {
                    GISGeoFunction geoFunc = new GISGeoFunction();

                    if (_pFeatureWorkspace == null) return;

                    IFeatureClass pFeatureClass = _pFeatureWorkspace.OpenFeatureClass(fClassName);
                    if (pFeatureClass.FeatureCount(null) > 0)
                    {
                        IGeometry geo = geoFunc.UnionGeometry(geometry);
                        pFCursor = geoFunc.SpatialFilterSearch(pFeatureClass, geo, string.Empty);

                        string[] fields = streamFielsName.Split(',');

                        IFeature pFeature = pFCursor.NextFeature();

                        while (pFeature != null)
                        {
                            DataRow row = table.NewRow();
                            row[0] = setValueToIndexField0;
                            row[1] = setValueToIndexField1;

                            foreach (string col in fields)
                            {
                                try
                                {
                                    if (pFeature.Fields.FindField(col) > -1)
                                        row[col] = pFeature.get_Value(pFeature.Fields.FindField(col));
                                }
                                catch { }
                            }

                            table.Rows.Add(row);
                            pFeature = pFCursor.NextFeature();
                        }
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
                finally
                {
                    //To fix Memory Problem
                    if (pFCursor != null) System.Runtime.InteropServices.Marshal.FinalReleaseComObject(pFCursor);
                    //if (pFCursor != null) System.Runtime.InteropServices.Marshal.ReleaseComObject(pFCursor);
                }
            }

            public void OpenGISGDBData(ref DataTable table, string fClassName, string streamFielsName, string whereClass)
            {
                IQueryFilter pQuery = null;
                IFeatureCursor pFCursor = null;

                try
                {
                    if (_pFeatureWorkspace == null) return;

                    IFeatureClass pFeatureClass = _pFeatureWorkspace.OpenFeatureClass(fClassName);

                    string[] fields = FindFieldExist(streamFielsName, pFeatureClass);

                    #region Re-format SubFields (IQueryFilter)

                    streamFielsName = string.Empty;
                    foreach (string field in fields)
                    {
                        if (!string.IsNullOrEmpty(streamFielsName))
                            streamFielsName = streamFielsName + ",";

                        streamFielsName = streamFielsName + field;
                    }

                    pQuery = new QueryFilter();
                    //Query.SubFields = streamFielsName;
                    pQuery.WhereClause = whereClass;

                    #endregion Re-format SubFields (IQueryFilter)

                    pFCursor = pFeatureClass.Search(pQuery, false);

                    IFeature pFeature = pFCursor.NextFeature();

                    while (pFeature != null)
                    {
                        if (table == null)
                            table = new DataTable();

                        DataRow row = table.NewRow();

                        if (table.Columns.Contains("Area"))
                        {
                            if (pFeature.Shape.GeometryType == esriGeometryType.esriGeometryPolygon)
                            {
                                IArea area = pFeature.Shape as IArea;
                                row["Area"] = area.Area;
                            }
                        }

                        foreach (string col in fields)
                        {
                            string type = row.Table.Columns[col].DataType.ToString();
                            object value = pFeature.get_Value(pFeature.Fields.FindField(col));

                            switch (type)
                            {
                                case "System.String":
                                    row[col] = value != null ? value.ToString() : string.Empty;
                                    break;
                                case "System.Int16":
                                    row[col] = value != null ? int.Parse(value.ToString()) : 0;
                                    break;
                                case "System.Int32":
                                    row[col] = value != null ? int.Parse(value.ToString()) : 0;
                                    break;
                                case "System.Double":
                                    row[col] = value != null ? double.Parse(value.ToString()) : 0;
                                    break;
                                case "System.Object":
                                    row[col] = value;
                                    break;
                            }
                        }

                        table.Rows.Add(row);
                        pFeature = pFCursor.NextFeature();
                    }
                }
                catch (Exception ex) { throw ex; }
                finally { if (pFCursor != null) { System.Runtime.InteropServices.Marshal.ReleaseComObject(pFCursor); } }
            }

            public void OpenGISShapeFile(ref DataTable table, string shapefileNamePath, string streamFielsName, string whereClass)
            {
                IQueryFilter pQuery = null;
                IFeatureCursor pFCursor = null;

                try
                {
                    IFeatureClass pFeatureClass = GetFeatureClassFromShapefile(shapefileNamePath);
                    string[] fields = FindFieldExist(streamFielsName, pFeatureClass);

                    #region Re-format SubFields (IQueryFilter)

                    streamFielsName = string.Empty;
                    foreach (string field in fields)
                    {
                        if (!string.IsNullOrEmpty(streamFielsName))
                            streamFielsName = streamFielsName + ",";

                        streamFielsName = streamFielsName + field;
                    }

                    pQuery = new QueryFilter();
                    pQuery.SubFields = streamFielsName;
                    pQuery.WhereClause = whereClass;

                    #endregion Re-format SubFields (IQueryFilter)

                    pFCursor = pFeatureClass.Search(pQuery, false);

                    IFeature pFeature = pFCursor.NextFeature();

                    while (pFeature != null)
                    {
                        if (table == null)
                            table = new DataTable();

                        DataRow row = table.NewRow();

                        foreach (string col in fields)
                        {
                            string type = row.Table.Columns[col].DataType.ToString();

                            switch (type)
                            {
                                case "System.String":
                                    row[col] = pFeature.get_Value(pFeature.Fields.FindField(col)) != null ? pFeature.get_Value(pFeature.Fields.FindField(col)).ToString() : string.Empty;
                                    break;
                                case "System.Int16":
                                    row[col] = pFeature.get_Value(pFeature.Fields.FindField(col)) != null ? int.Parse(pFeature.get_Value(pFeature.Fields.FindField(col)).ToString()) : 0;
                                    break;
                                case "System.Int32":
                                    row[col] = pFeature.get_Value(pFeature.Fields.FindField(col)) != null ? int.Parse(pFeature.get_Value(pFeature.Fields.FindField(col)).ToString()) : 0;
                                    break;
                                case "System.Double":
                                    row[col] = pFeature.get_Value(pFeature.Fields.FindField(col)) != null ? double.Parse(pFeature.get_Value(pFeature.Fields.FindField(col)).ToString()) : 0;
                                    break;
                                case "System.Object":
                                    row[col] = pFeature.get_Value(pFeature.Fields.FindField(col)) != null ? pFeature.get_Value(pFeature.Fields.FindField(col)) : null;
                                    break;
                            }

                            //if (col == "Shape")
                            //    row[col] = pFeature.get_Value(pFeature.Fields.FindField(col)) != null ? pFeature.get_Value(pFeature.Fields.FindField(col)) : null;
                            //else
                            //{
                            //    if (row[col].GetType() == typeof(System.String))
                            //        row[col] = pFeature.get_Value(pFeature.Fields.FindField(col)) != null ? pFeature.get_Value(pFeature.Fields.FindField(col)).ToString() : string.Empty;
                            //    else if (row[col].GetType() == typeof(System.Int16) || row[col].GetType() == typeof(System.Int32))
                            //        row[col] = pFeature.get_Value(pFeature.Fields.FindField(col)) != null ? int.Parse(pFeature.get_Value(pFeature.Fields.FindField(col)).ToString()) : 0;
                            //    else if (row[col].GetType() == typeof(System.Double))
                            //        row[col] = pFeature.get_Value(pFeature.Fields.FindField(col)) != null ? double.Parse(pFeature.get_Value(pFeature.Fields.FindField(col)).ToString()) : 0;
                            //}
                            //row[col] = pFeature.get_Value(pFeature.Fields.FindField(col)) != null ? pFeature.get_Value(pFeature.Fields.FindField(col)).ToString() : string.Empty;
                        }

                        table.Rows.Add(row);
                        pFeature = pFCursor.NextFeature();
                    }
                }
                catch (Exception ex) { }
                finally { if (pFCursor != null) { System.Runtime.InteropServices.Marshal.ReleaseComObject(pFCursor); } }
            }

            public IFeatureClass GetFeatureClassFromShapefile(string shapefileName)
            {
                if (System.IO.File.Exists(shapefileName))
                {
                    ESRI.ArcGIS.Geodatabase.IWorkspaceFactory workspaceFactory = new ESRI.ArcGIS.DataSourcesFile.ShapefileWorkspaceFactoryClass();
                    ESRI.ArcGIS.Geodatabase.IWorkspace workspace = workspaceFactory.OpenFromFile(System.IO.Path.GetDirectoryName(shapefileName), 0);
                    ESRI.ArcGIS.Geodatabase.IFeatureWorkspace featureWorkspace = (ESRI.ArcGIS.Geodatabase.IFeatureWorkspace)workspace; // Explict Cast
                    ESRI.ArcGIS.Geodatabase.IFeatureClass featureClass = featureWorkspace.OpenFeatureClass(System.IO.Path.GetFileNameWithoutExtension(shapefileName));

                    return featureClass;
                }
                else
                {
                    //Not valid shapefile
                    return null;
                }
            }

            public void GetMISTable(ref DataTable table, string tableName, string streamFielsName, string whereClass)
            {
                ITable pTable = null;
                IQueryFilter pQuery = null;
                ICursor pCursor = null;

                try
                {
                    pTable = _pFeatureWorkspace.OpenTable(tableName);

                    string[] fields = streamFielsName.Split(',');

                    pQuery = new QueryFilter();
                    pQuery.SubFields = streamFielsName;
                    pQuery.WhereClause = whereClass;

                    pCursor = pTable.Search(pQuery, true);
                    IRow pRow = pCursor.NextRow();

                    while (pRow != null)
                    {
                        DataRow row = table.NewRow();

                        foreach (string col in fields)
                        {
                            string type = row.Table.Columns[col].DataType.ToString();

                            switch (type)
                            {
                                case "System.String":
                                    row[col] = pRow.get_Value(pRow.Fields.FindField(col)) != null ? pRow.get_Value(pRow.Fields.FindField(col)).ToString() : string.Empty;
                                    break;
                                case "System.Int16":
                                    row[col] = pRow.get_Value(pRow.Fields.FindField(col)) != null ? int.Parse(pRow.get_Value(pRow.Fields.FindField(col)).ToString()) : 0;
                                    break;
                                case "System.Int32":
                                    row[col] = pRow.get_Value(pRow.Fields.FindField(col)) != null ? int.Parse(pRow.get_Value(pRow.Fields.FindField(col)).ToString()) : 0;
                                    break;
                                case "System.Double":
                                    row[col] = pRow.get_Value(pRow.Fields.FindField(col)) != null ? double.Parse(pRow.get_Value(pRow.Fields.FindField(col)).ToString()) : 0;
                                    break;
                                case "System.Object":
                                    row[col] = pRow.get_Value(pRow.Fields.FindField(col)) != null ? pRow.get_Value(pRow.Fields.FindField(col)) : null;
                                    break;
                            }

                            //if (row[col].GetType() == typeof(System.String))
                            //    row[col] = pRow.get_Value(pRow.Fields.FindField(col)) != null ? pRow.get_Value(pRow.Fields.FindField(col)).ToString() : string.Empty;
                            //else if (row[col].GetType() == typeof(System.Int16) || row[col].GetType() == typeof(System.Int32))
                            //    row[col] = pRow.get_Value(pRow.Fields.FindField(col)) != null ? int.Parse(pRow.get_Value(pRow.Fields.FindField(col)).ToString()) : 0;
                            //else if (row[col].GetType() == typeof(System.Double))
                            //    row[col] = pRow.get_Value(pRow.Fields.FindField(col)) != null ? double.Parse(pRow.get_Value(pRow.Fields.FindField(col)).ToString()) : 0;
                            //row[col] = pRow.get_Value(pRow.Fields.FindField(col));
                        }

                        table.Rows.Add(row);
                        pRow = pCursor.NextRow();
                    }
                }
                catch (Exception ex) { throw ex; }
                finally
                {
                    if (pCursor != null) { System.Runtime.InteropServices.Marshal.ReleaseComObject(pCursor); }
                }
            }

            public DataTable GetMISTable(string tableName, string whereClass)
            {
                ITable pTable = null;
                IQueryFilter pQuery = null;
                ICursor pCursor = null;

                try
                {
                    DataTable table = new DataTable();
                    pTable = _pFeatureWorkspace.OpenTable(tableName);

                    pQuery = new QueryFilter();
                    pQuery.WhereClause = whereClass;
                    pCursor = pTable.Search(pQuery, false);

                    //Create Data Column.
                    IFields pFields = pTable.Fields;
                    for (int i = 0; i < pFields.FieldCount; i++) { table.Columns.Add(pFields.get_Field(i).Name); }

                    IRow pRow = pCursor.NextRow();
                    while (pRow != null)
                    {
                        DataRow row = table.NewRow();

                        foreach (DataColumn col in table.Columns)
                        {
                            string type = col.DataType.ToString();

                            switch (type)
                            {
                                case "System.String":
                                    row[col.ColumnName] = pRow.get_Value(pRow.Fields.FindField(col.ColumnName)) != null ? pRow.get_Value(pRow.Fields.FindField(col.ColumnName)).ToString() : string.Empty;
                                    break;
                                case "System.Int16":
                                    row[col.ColumnName] = pRow.get_Value(pRow.Fields.FindField(col.ColumnName)) != null ? int.Parse(pRow.get_Value(pRow.Fields.FindField(col.ColumnName)).ToString()) : 0;
                                    break;
                                case "System.Int32":
                                    row[col.ColumnName] = pRow.get_Value(pRow.Fields.FindField(col.ColumnName)) != null ? int.Parse(pRow.get_Value(pRow.Fields.FindField(col.ColumnName)).ToString()) : 0;
                                    break;
                                case "System.Double":
                                    row[col.ColumnName] = pRow.get_Value(pRow.Fields.FindField(col.ColumnName)) != null ? double.Parse(pRow.get_Value(pRow.Fields.FindField(col.ColumnName)).ToString()) : 0;
                                    break;
                                case "System.Object":
                                    row[col.ColumnName] = pRow.get_Value(pRow.Fields.FindField(col.ColumnName)) != null ? pRow.get_Value(pRow.Fields.FindField(col.ColumnName)) : null;
                                    break;
                            }
                            //if (row[col.ColumnName].GetType() == typeof(System.String))
                            //    row[col.ColumnName] = pRow.get_Value(pRow.Fields.FindField(col.ColumnName)) != null ? pRow.get_Value(pRow.Fields.FindField(col.ColumnName)).ToString() : string.Empty;
                            //else if (row[col].GetType() == typeof(System.Int16) || row[col].GetType() == typeof(System.Int32))
                            //    row[col.ColumnName] = pRow.get_Value(pRow.Fields.FindField(col.ColumnName)) != null ? int.Parse(pRow.get_Value(pRow.Fields.FindField(col.ColumnName)).ToString()) : 0;
                            //else if (row[col].GetType() == typeof(System.Double))
                            //    row[col.ColumnName] = pRow.get_Value(pRow.Fields.FindField(col.ColumnName)) != null ? double.Parse(pRow.get_Value(pRow.Fields.FindField(col.ColumnName)).ToString()) : 0;
                            //row[col.ColumnName] = pRow.get_Value(pRow.Fields.FindField(col.ColumnName)).ToString();
                        }

                        table.Rows.Add(row);
                        pRow = pCursor.NextRow();
                    }

                    return table;
                }
                catch { return null; }
                finally
                {
                    if (pCursor != null) { System.Runtime.InteropServices.Marshal.ReleaseComObject(pCursor); }
                }
            }

            public string[] FindFieldExist(string streamFielsName, IFeatureClass pFeatureClass)
            {
                try
                {
                    int c = 0;
                    string[] fieldExist = streamFielsName.Split(',');

                    foreach (string field in fieldExist)
                    {
                        if (pFeatureClass.Fields.FindField(field) == -1)
                        {
                            streamFielsName = streamFielsName.Replace(field, string.Empty);
                        }
                    }

                    fieldExist = streamFielsName.Split(',');
                    var revers = fieldExist.Where(r => r != string.Empty).ToArray();
                    return revers;// fieldExist;
                }
                catch (Exception ex)
                {
                    //Write Log.
                    //_pFeatureWorkspace :
                    //Layer Name : 
                    return null;
                }
            }
        }
    }
}

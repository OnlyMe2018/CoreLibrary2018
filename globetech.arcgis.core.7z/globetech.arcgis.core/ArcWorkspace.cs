﻿using ESRI.ArcGIS.esriSystem;
using ESRI.ArcGIS.Geodatabase;
using ESRI.ArcGIS.DataSourcesFile;
using ESRI.ArcGIS.DataSourcesGDB;

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace globetech.arcgis.core
{
    public class ArcWorkspace
    {
        // For example, database = "C:\\myData\\myfGDB.gdb".
        internal protected IWorkspace FileGdbWorkspaceFromPropertySet(string database)
        {
            IPropertySet propertySet = new PropertySetClass();
            propertySet.SetProperty("DATABASE", database);
            IWorkspaceFactory workspaceFactory = new FileGDBWorkspaceFactoryClass();
            return workspaceFactory.Open(propertySet, 0);
        }

        // For example, path = "C:\\myData".
        internal protected IWorkspace ShapefileWorkspaceFromPropertySet(string path)
        {
            IPropertySet propertySet = new PropertySetClass();
            propertySet.SetProperty("DATABASE", path);
            IWorkspaceFactory workspaceFactory = new ShapefileWorkspaceFactoryClass();
            return workspaceFactory.Open(propertySet, 0);
        }
    }
}

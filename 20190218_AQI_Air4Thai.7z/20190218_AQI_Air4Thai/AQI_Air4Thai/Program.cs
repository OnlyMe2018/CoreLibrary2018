﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using System.Net;
using System.IO;
using System.Xml;
using System.Data;
using System.Data.SqlClient;


namespace AQI_Air4Thai
{
    class Program
    {
        static void Main(string[] args)
        {
            string fileName = string.Empty;
            string timenow = DateTime.Now.ToString("HH:mm");
            string activeDir = AppDomain.CurrentDomain.BaseDirectory;
            string desPath2 = System.IO.Path.Combine(activeDir, "Log" + @"\");
            System.IO.Directory.CreateDirectory(desPath2);
            string desPath = System.IO.Path.Combine(desPath2, fileName);
            StringBuilder sb = new StringBuilder();
            if (DateTime.Now.Hour >= 00)
            {
                fileName = "logfile" + DateTime.Now.ToString("MM-dd-yyyy") + ".txt";
            }
            else
            {
                fileName = "logfile" + DateTime.Now.ToString("MM-dd-yyyy") + ".txt";
            }
            sb.Append(Environment.NewLine + "Start PROCESS " + DateTime.Now.ToString());

            try
            {
                string html = string.Empty;
                string url = ConfigurationManager.AppSettings["Service_url"].ToString();
                string connectionString = ConfigurationManager.AppSettings["Connectiondb_String"].ToString();
                string config_TempTablename = ConfigurationManager.AppSettings["DB_TempTableName"].ToString();
                string config_LogTablename = ConfigurationManager.AppSettings["DB_LogTableName"].ToString();

                //GET DATA FORM URL
                XmlDocument xdoc = new XmlDocument();
                HttpWebRequest request = (HttpWebRequest)WebRequest.Create(url);
                try
                {
                    sb.Append(Environment.NewLine + "Start Connect Service ");
                    using (HttpWebResponse response = (HttpWebResponse)request.GetResponse())
                    using (Stream stream = response.GetResponseStream())
                    using (StreamReader reader = new StreamReader(stream))
                    {
                        html = reader.ReadToEnd();
                    }
                }
                catch (Exception ex)
                {
                    sb.Append(Environment.NewLine + ex.Message + " " + DateTime.Now.ToString());
                    sb.Append(Environment.NewLine + "*****************");
                    File.AppendAllText(desPath + fileName, sb.ToString());
                    sb.Clear();
                    return;
                }

                xdoc.Load(new StringReader(html));
                DataTable Dt = new DataTable();
                DataTable result = new DataTable();
                XmlNode NodoEstructura = xdoc.FirstChild.FirstChild;


                //  Table structure (columns definition) 
                foreach (XmlNode columna in NodoEstructura.ChildNodes)
                {
                    if (columna.Name != "LastUpdate")
                    {
                        if ((columna.Name == "lat") || (columna.Name == "long"))
                        {
                            Dt.Columns.Add(columna.Name, typeof(Double));
                        }
                        else
                            Dt.Columns.Add(columna.Name, typeof(String));
                    }
                    else if (columna.Name == "LastUpdate")
                    {
                        foreach (XmlNode subCol in columna.ChildNodes)
                        {
                            if (subCol.Name == "date")
                            {
                                Dt.Columns.Add("LastUpdateDate", typeof(String));
                            }
                            else if (subCol.Name == "time")
                            {
                                Dt.Columns.Add("LastUpdateTime", typeof(String));
                            }
                            else if (subCol.Name == "CO")
                            {
                                Dt.Columns.Add("CO_value", typeof(Double));
                                Dt.Columns.Add("CO_unit", typeof(String));
                            }
                            else if (subCol.Name == "AQI")
                            {
                                Dt.Columns.Add("AQI_Level", typeof(Int32));
                                Dt.Columns.Add("AQI_aqi", typeof(Int32));
                            }
                            else
                            {
                                Dt.Columns.Add(subCol.Name + "_value", typeof(Int32));
                                Dt.Columns.Add(subCol.Name + "_unit", typeof(String));
                            }
                        }
                    }
                }
                XmlNode Filas = xdoc.FirstChild;
                //  Table structure (Rows definition) 
                try
                {
                    sb.Append(Environment.NewLine + "Read Data to Datatable ");
                    foreach (XmlNode Fila in Filas.ChildNodes)
                    {
                        DataRow rw = Dt.NewRow();
                        foreach (XmlNode Columna in Fila.ChildNodes)
                        {
                            if (Columna.Name != "LastUpdate")
                            {
                                rw[Columna.Name] = Columna.InnerText;
                            }
                            else if (Columna.Name == "LastUpdate")
                            {
                                foreach (XmlNode subCol in Columna.ChildNodes)
                                {
                                    if (subCol.Name == "date")
                                    {
                                        rw["LastUpdateDate"] = subCol.InnerXml;
                                    }
                                    else if (subCol.Name == "time")
                                    {
                                        rw["LastUpdateTime"] = subCol.InnerXml;
                                    }
                                    else if (subCol.Name == "AQI")
                                    {
                                        int level = Convert.ToInt32(subCol.Attributes["Level"].Value);
                                        rw["AQI_Level"] = level;
                                        int aqi = Convert.ToInt32(subCol.Attributes["aqi"].Value);
                                        rw["AQI_aqi"] = aqi;
                                    }
                                    else if (subCol.Name == "CO")
                                    {
                                        if ((subCol.Attributes["value"].Value == "-") || (subCol.Attributes["value"].Value == "N/A"))
                                        {
                                            rw[subCol.Name + "_value"] = DBNull.Value;
                                            rw[subCol.Name + "_unit"] = subCol.Attributes["unit"].Value;
                                        }
                                        else
                                        {
                                            double valueCO = Convert.ToDouble(subCol.Attributes["value"].Value);
                                            rw[subCol.Name + "_value"] = valueCO;
                                            rw[subCol.Name + "_unit"] = subCol.Attributes["unit"].Value;
                                        }
                                    }
                                    else
                                    {
                                        if ((subCol.Attributes["value"].Value == "-") || (subCol.Attributes["value"].Value == "N/A"))
                                        {
                                            rw[subCol.Name + "_value"] = DBNull.Value;
                                            rw[subCol.Name + "_unit"] = subCol.Attributes["unit"].Value;
                                        }
                                        else
                                        {
                                            int value = Convert.ToInt32(subCol.Attributes["value"].Value);
                                            rw[subCol.Name + "_value"] = value;
                                            rw[subCol.Name + "_unit"] = subCol.Attributes["unit"].Value;
                                        }
                                    }
                                }
                            }
                        }
                        Dt.Rows.Add(rw);
                    }
                }
                catch (Exception ex)
                {
                    sb.Append(Environment.NewLine + ex.Message + " " + DateTime.Now.ToString());
                    sb.Append(Environment.NewLine + "*****************");
                    File.AppendAllText(desPath + fileName, sb.ToString());
                    sb.Clear();
                    return;
                }
                try
                {
                    string query = "select * from " + config_TempTablename;
                    DataTable temp = new DataTable();
                    SqlConnection conn = new SqlConnection(connectionString);
                    SqlCommand cmd = new SqlCommand(query, conn);
                    conn.Open();
                    // create data adapter
                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    // this will query your database and return the result to your datatable
                    da.Fill(temp);
                    conn.Close();
                    da.Dispose();

                    var w = from A in Dt.AsEnumerable()
                            join B in temp.AsEnumerable() on A.Field<string>("stationID") equals B.Field<string>("stationID")
                            where A.Field<string>("stationID") == B.Field<string>("stationID") && ((Convert.ToDateTime(A.Field<string>("LastUpdateDate")) >= Convert.ToDateTime(B.Field<string>("LastUpdateDate")) && Convert.ToDateTime(A.Field<string>("LastUpdateTime")) > Convert.ToDateTime(B.Field<string>("LastUpdateTime"))) || (Convert.ToDateTime(A.Field<string>("LastUpdateDate")) > Convert.ToDateTime(B.Field<string>("LastUpdateDate")) && Convert.ToDateTime(A.Field<string>("LastUpdateTime")) <= Convert.ToDateTime(B.Field<string>("LastUpdateTime"))))
                            select A;

                    result = Dt.Copy();
                    result.Clear();
                    foreach (var item in w)
                    {
                        result.Rows.Add(item.ItemArray);
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex);
                }
                //Connection Databse Sever and Bulk Copy Datatable to Database
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    try
                    {
                        connection.Open();
                        string sqlTrunc = "TRUNCATE TABLE " + config_TempTablename;
                        SqlCommand cmd = new SqlCommand(sqlTrunc, connection);
                        cmd.ExecuteNonQuery();
                    }
                    catch (Exception ex)
                    {
                        sb.Append(Environment.NewLine + ex.Message + " " + DateTime.Now.ToString());
                        sb.Append(Environment.NewLine + "*****************");
                        File.AppendAllText(desPath + fileName, sb.ToString());
                        sb.Clear();
                        return;
                    }
                    using (SqlBulkCopy bulkCopy = new SqlBulkCopy(connection))
                    {
                        foreach (DataColumn c in Dt.Columns)
                            bulkCopy.ColumnMappings.Add(c.ColumnName, c.ColumnName);

                        bulkCopy.DestinationTableName = config_TempTablename;
                        try
                        {
                            sb.Append(Environment.NewLine + "update data to Server");
                            bulkCopy.WriteToServer(Dt);
                        }
                        catch (Exception ex)
                        {
                            sb.Append(Environment.NewLine + "Update Failed!!");
                            sb.Append(Environment.NewLine + ex.ToString());
                        }
                    }
                    using (SqlBulkCopy bulkCopy2 = new SqlBulkCopy(connection))
                    {
                        foreach (DataColumn c in result.Columns)
                            bulkCopy2.ColumnMappings.Add(c.ColumnName, c.ColumnName);

                        bulkCopy2.DestinationTableName = config_LogTablename;
                        try
                        {
                            sb.Append(Environment.NewLine + "update data to Log");
                            bulkCopy2.WriteToServer(result);
                        }
                        catch (Exception ex)
                        {
                            sb.Append(Environment.NewLine + "update Failed!!");
                            sb.Append(Environment.NewLine + ex.ToString());
                        }
                    }
                    connection.Close();


                    sb.Append(Environment.NewLine + "Procress Complete");
                    sb.Append(Environment.NewLine + "*****************");
                    File.AppendAllText(desPath + fileName, sb.ToString());
                    sb.Clear();
                }
            }
            catch (Exception ex)
            {
                sb.Append(Environment.NewLine + "Procress Complete");
                sb.Append(Environment.NewLine + "*****************");
            }
            File.AppendAllText(desPath + fileName, sb.ToString());
            sb.Clear();
        }
    }
}

﻿using FluentFTP;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Authentication;
using System.Text;
using System.Threading.Tasks;

namespace FTPsFileTransfer
{
    internal class FTPsTransfer
    {
        private int _totalOfSuccess = 0;

        internal int TotalOfSuccess
        {
            get { return _totalOfSuccess; }
        }

        private int _totalOfFailed = 0;
        internal int TotalOfFailed
        {
            get { return _totalOfFailed; }
        }

        private FTPsTransferModel _ftpModel = null;
        internal FTPsTransfer(FTPsTransferModel model)
        {
            _ftpModel = model;
        }

        internal static bool TestFTPsConnection(string host, int port,string user,string pass)
        {
            try
            {
                bool success;
                FtpClient client = new FtpClient(host, port, user, pass); // or set Host & Credentials
                client.EncryptionMode = FtpEncryptionMode.None;
                client.SslProtocols = SslProtocols.Ssl2;
                client.ValidateCertificate += new FtpSslValidation(OnValidateCertificate);
                client.Connect();
                success = client.IsConnected;
                return success;
            }
            catch (Exception ex)
            {
                
                throw ex;
            }
        }
        static void OnValidateCertificate(FtpClient control, FtpSslValidationEventArgs e)
        {
            // add logic to test if certificate is valid here
            e.Accept = true;
        }
        
        internal static void FTPsDownloadFile(string host, int port, string user, string pass,string FTPsFilePath,string FTPsHistoryPath,string LocalDesPath)
        {
            try
            {
                
                //If Sucess
                bool success;
                FtpClient client = new FtpClient(host, port, user, pass); // or set Host & Credentials
                client.EncryptionMode = FtpEncryptionMode.None;
                client.SslProtocols = SslProtocols.Ssl2;
                client.ValidateCertificate += new FtpSslValidation(OnValidateCertificate);
                client.Connect();
                success = client.IsConnected;
                if (success == true)
                {
                    FtpListItem[]  numFilesDownloaded = client.GetListing(FTPsFilePath, FtpListOption.AllFiles);
                    
                    int i = numFilesDownloaded.Count();
                    foreach (FtpListItem item in numFilesDownloaded)
                    {    
                        FileInfo fileInfo = new FileInfo(item.Name.ToString());
                        string FileEx = fileInfo.Extension.ToString();


                        if (FileEx == ".json")
                        {
                            client.DownloadFile(LocalDesPath + "/" + item.Name,item.FullName);
                            if(FTPsHistoryPath != "")
                            {
                                client.MoveFile(item.FullName, FTPsHistoryPath + "/" + item.Name);
                            }
                        }
                    }
                    

                }
                client.Disconnect();
            }
            catch (Exception ex)
            {
              
            }
        }

        private bool CopyToFilePath(string sourcs_path, string destination_path)
        {
            try
            {
                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
        }

        private bool MoveToFilePath(string sourcs_path, string destination_path)
        {
            try
            {
                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
        }
    }
}

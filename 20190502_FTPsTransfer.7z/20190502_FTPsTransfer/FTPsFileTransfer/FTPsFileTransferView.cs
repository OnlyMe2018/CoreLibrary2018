﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using FTPsFileTransfer;
using FluentFTP;

namespace FTPsFileTransfer
{
    public partial class FTPsFileTransferView : Form
    {
        private Configuration _configuration = ConfigurationManager.OpenExeConfiguration(ConfigurationUserLevel.None);

        public FTPsFileTransferView()
        {
            InitializeComponent();
        }

        private void FTPsFileTransferView_Load(object sender, EventArgs e)
        {
            txtFTPsIPAddress.Text = ConfigurationManager.AppSettings["FTPsIPAddress"].ToString();
            txtFTPsUsername.Text = ConfigurationManager.AppSettings["FTPsUsername"].ToString();
            txtFTPsPassword.Text = ConfigurationManager.AppSettings["FTPsPassword"].ToString();
            txtFTPsPort.Text = ConfigurationManager.AppSettings["FTPsPort"].ToString();
            txtFTPsFilePath.Text = ConfigurationManager.AppSettings["FTPsFilePath"].ToString();
            txtFTPsHistoryPath.Text = ConfigurationManager.AppSettings["FTPsHistoryPath"].ToString();
            txtLocalDesPath.Text = ConfigurationManager.AppSettings["LocalDesPath"].ToString();
            chkJson.Checked = ConfigurationManager.AppSettings["FileExtJson"].ToString() == "False" ? false : true;
            chkXml.Checked = ConfigurationManager.AppSettings["FileExtXml"].ToString() == "False" ? false : true;
            chkExcel.Checked = ConfigurationManager.AppSettings["FileExtExcel"].ToString() == "False" ? false : true;
            chkDoc.Checked = ConfigurationManager.AppSettings["FileExtDoc"].ToString() == "False" ? false : true;
            chkText.Checked = ConfigurationManager.AppSettings["FileExtText"].ToString() == "False" ? false : true;
            chkPdf.Checked = ConfigurationManager.AppSettings["FileExtPdf"].ToString() == "False" ? false : true;
            chkNone.Checked = ConfigurationManager.AppSettings["FileExtNone"].ToString() == "False" ? false : true;
            txtLogPath.Text = ConfigurationManager.AppSettings["LogPath"].ToString();
        }


        private void btnTestFTPsConnection_Click(object sender, EventArgs e)
        {
            //Test FTPs Connection.
            try
            {

                bool check = FTPsTransfer.TestFTPsConnection(txtFTPsIPAddress.Text, Convert.ToInt32(txtFTPsPort.Text), txtFTPsUsername.Text, txtFTPsPassword.Text);
                if (check != true)
                {
                    txtLog.Text = "Connection Failed";
                }
                else
                    txtLog.Text = "Connection Success!!";
            }
            catch (Exception ex)
            {
                txtLog.Text = ex.ToString()+ "Connection Failed";
                
                return;
            }
        }

        static void wc_DownloadFileCompleted(object sender, AsyncCompletedEventArgs e)
        {

            System.Uri url = new Uri("ftp://Username:Password@ServerIP/DestinationFileName");
            System.Net.WebClient wc = new System.Net.WebClient();
            wc.UploadFile(url, @"C:\YourFolderName\SourceFileName");
            wc.UploadFileCompleted += new System.Net.UploadFileCompletedEventHandler(wc_UploadFileCompleted);
        }

        static void wc_UploadFileCompleted(object sender, System.Net.UploadFileCompletedEventArgs e)
        {
            MessageBox.Show("File has been moved");
        }


        private void FTPsFileTransferView_FormClosing(object sender, FormClosingEventArgs e)
        {
            //Save Configuration to App
            SaveConfigurationToAppConfig("FTPsIPAddress", txtFTPsIPAddress.Text);
            SaveConfigurationToAppConfig("FTPsUsername", txtFTPsUsername.Text);
            SaveConfigurationToAppConfig("FTPsPassword", txtFTPsPassword.Text);
            SaveConfigurationToAppConfig("FTPsPort", txtFTPsPort.Text);
            SaveConfigurationToAppConfig("FTPsFilePath", txtFTPsFilePath.Text);
            SaveConfigurationToAppConfig("FTPsHistoryPath", txtFTPsHistoryPath.Text);
            SaveConfigurationToAppConfig("LocalDesPath", txtLocalDesPath.Text);
            SaveConfigurationToAppConfig("FileExtJson", chkJson.Checked.ToString());
            SaveConfigurationToAppConfig("FileExtXml", chkXml.Checked.ToString());
            SaveConfigurationToAppConfig("FileExtExcel", chkExcel.Checked.ToString());
            SaveConfigurationToAppConfig("FileExtDoc", chkDoc.Checked.ToString());
            SaveConfigurationToAppConfig("FileExtText", chkText.Checked.ToString());
            SaveConfigurationToAppConfig("FileExtPdf", chkPdf.Checked.ToString());
            SaveConfigurationToAppConfig("FileExtNone", chkNone.Checked.ToString());
            SaveConfigurationToAppConfig("LogPath", txtLogPath.Text.ToString());
        }
        
        private bool SaveConfigurationToAppConfig(string key,string value)
        {
            try
            {
                Configuration configuration = ConfigurationManager.OpenExeConfiguration(ConfigurationUserLevel.None);
                configuration.AppSettings.Settings[key].Value = value;
                configuration.Save(ConfigurationSaveMode.Full, true);
                ConfigurationManager.RefreshSection("appSettings");
                return true;
            }
            catch (Exception ex)
            {
                txtLog.Text = ex.ToString();
                return false;
            }
        }


        private string ReadConfigurationToAppConfig(string key)
        {
            try
            {
                return _configuration.AppSettings.Settings[key].Value;
                }
            catch(Exception ex)
            {
                //WriteLog.
                return string.Empty;
            }            
        }

    
        private void btnLocalDesPath_Click(object sender, EventArgs e)
        {
            using (var fbd = new FolderBrowserDialog())
            {
                DialogResult result = fbd.ShowDialog();
                if (result == DialogResult.OK && !string.IsNullOrWhiteSpace(fbd.SelectedPath))
                {
                    txtLocalDesPath.Text = fbd.SelectedPath.ToString();
                }
            }
        }

        private void btnFTPsDownaload_Click(object sender, EventArgs e)
        {
    
            FTPsTransfer.FTPsDownloadFile(txtFTPsIPAddress.Text, Convert.ToInt32(txtFTPsPort.Text), txtFTPsUsername.Text, txtFTPsPassword.Text,txtFTPsFilePath.Text, txtFTPsHistoryPath.Text, txtLocalDesPath.Text);
            

        }

        private void btnLogPath_Click(object sender, EventArgs e)
        {
            using (var fbd = new FolderBrowserDialog())
            {
                DialogResult result = fbd.ShowDialog();
                if (result == DialogResult.OK && !string.IsNullOrWhiteSpace(fbd.SelectedPath))
                {
                    txtLogPath.Text = fbd.SelectedPath.ToString();
                }
            }
        }
    }
}

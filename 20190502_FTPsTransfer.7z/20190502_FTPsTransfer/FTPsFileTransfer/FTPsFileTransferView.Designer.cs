﻿namespace FTPsFileTransfer
{
    partial class FTPsFileTransferView
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtLog = new System.Windows.Forms.TextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.txtFTPsPort = new System.Windows.Forms.TextBox();
            this.txtFTPsPassword = new System.Windows.Forms.TextBox();
            this.txtFTPsUsername = new System.Windows.Forms.TextBox();
            this.txtFTPsIPAddress = new System.Windows.Forms.TextBox();
            this.btnFTPsConnect = new System.Windows.Forms.Button();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.btnLogPath = new System.Windows.Forms.Button();
            this.label9 = new System.Windows.Forms.Label();
            this.txtLogPath = new System.Windows.Forms.TextBox();
            this.btnLocalDesPath = new System.Windows.Forms.Button();
            this.chkNone = new System.Windows.Forms.CheckBox();
            this.chkPdf = new System.Windows.Forms.CheckBox();
            this.chkText = new System.Windows.Forms.CheckBox();
            this.chkDoc = new System.Windows.Forms.CheckBox();
            this.label8 = new System.Windows.Forms.Label();
            this.chkExcel = new System.Windows.Forms.CheckBox();
            this.chkXml = new System.Windows.Forms.CheckBox();
            this.chkJson = new System.Windows.Forms.CheckBox();
            this.btnFTPsDownaload = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.txtLocalDesPath = new System.Windows.Forms.TextBox();
            this.txtFTPsHistoryPath = new System.Windows.Forms.TextBox();
            this.txtFTPsFilePath = new System.Windows.Forms.TextBox();
            this.groupBox1.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // txtLog
            // 
            this.txtLog.Location = new System.Drawing.Point(16, 346);
            this.txtLog.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtLog.Multiline = true;
            this.txtLog.Name = "txtLog";
            this.txtLog.Size = new System.Drawing.Size(608, 184);
            this.txtLog.TabIndex = 8;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.txtFTPsPort);
            this.groupBox1.Controls.Add(this.txtFTPsPassword);
            this.groupBox1.Controls.Add(this.txtFTPsUsername);
            this.groupBox1.Controls.Add(this.txtFTPsIPAddress);
            this.groupBox1.Controls.Add(this.btnFTPsConnect);
            this.groupBox1.Location = new System.Drawing.Point(3, 6);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(596, 253);
            this.groupBox1.TabIndex = 9;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "FTPs Information";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(55, 144);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(38, 20);
            this.label4.TabIndex = 9;
            this.label4.Text = "Port";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(15, 112);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(78, 20);
            this.label3.TabIndex = 8;
            this.label3.Text = "Password";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(10, 80);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(83, 20);
            this.label2.TabIndex = 7;
            this.label2.Text = "Username";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(6, 48);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(87, 20);
            this.label1.TabIndex = 6;
            this.label1.Text = "IP Address";
            // 
            // txtFTPsPort
            // 
            this.txtFTPsPort.Location = new System.Drawing.Point(98, 141);
            this.txtFTPsPort.Name = "txtFTPsPort";
            this.txtFTPsPort.Size = new System.Drawing.Size(182, 26);
            this.txtFTPsPort.TabIndex = 5;
            // 
            // txtFTPsPassword
            // 
            this.txtFTPsPassword.Location = new System.Drawing.Point(98, 109);
            this.txtFTPsPassword.Name = "txtFTPsPassword";
            this.txtFTPsPassword.Size = new System.Drawing.Size(182, 26);
            this.txtFTPsPassword.TabIndex = 4;
            // 
            // txtFTPsUsername
            // 
            this.txtFTPsUsername.Location = new System.Drawing.Point(98, 77);
            this.txtFTPsUsername.Name = "txtFTPsUsername";
            this.txtFTPsUsername.Size = new System.Drawing.Size(182, 26);
            this.txtFTPsUsername.TabIndex = 3;
            // 
            // txtFTPsIPAddress
            // 
            this.txtFTPsIPAddress.Location = new System.Drawing.Point(98, 45);
            this.txtFTPsIPAddress.Name = "txtFTPsIPAddress";
            this.txtFTPsIPAddress.Size = new System.Drawing.Size(182, 26);
            this.txtFTPsIPAddress.TabIndex = 2;
            // 
            // btnFTPsConnect
            // 
            this.btnFTPsConnect.Location = new System.Drawing.Point(361, 176);
            this.btnFTPsConnect.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnFTPsConnect.Name = "btnFTPsConnect";
            this.btnFTPsConnect.Size = new System.Drawing.Size(202, 29);
            this.btnFTPsConnect.TabIndex = 1;
            this.btnFTPsConnect.Text = "Connect";
            this.btnFTPsConnect.UseVisualStyleBackColor = true;
            this.btnFTPsConnect.Click += new System.EventHandler(this.btnTestFTPsConnection_Click);
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Location = new System.Drawing.Point(12, 13);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(613, 326);
            this.tabControl1.TabIndex = 10;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.groupBox1);
            this.tabPage1.Location = new System.Drawing.Point(4, 29);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(605, 293);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Connection";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.groupBox2);
            this.tabPage2.Location = new System.Drawing.Point(4, 29);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(605, 293);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "DownloadFile";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.btnLogPath);
            this.groupBox2.Controls.Add(this.label9);
            this.groupBox2.Controls.Add(this.txtLogPath);
            this.groupBox2.Controls.Add(this.btnLocalDesPath);
            this.groupBox2.Controls.Add(this.chkNone);
            this.groupBox2.Controls.Add(this.chkPdf);
            this.groupBox2.Controls.Add(this.chkText);
            this.groupBox2.Controls.Add(this.chkDoc);
            this.groupBox2.Controls.Add(this.label8);
            this.groupBox2.Controls.Add(this.chkExcel);
            this.groupBox2.Controls.Add(this.chkXml);
            this.groupBox2.Controls.Add(this.chkJson);
            this.groupBox2.Controls.Add(this.btnFTPsDownaload);
            this.groupBox2.Controls.Add(this.label7);
            this.groupBox2.Controls.Add(this.label6);
            this.groupBox2.Controls.Add(this.label5);
            this.groupBox2.Controls.Add(this.txtLocalDesPath);
            this.groupBox2.Controls.Add(this.txtFTPsHistoryPath);
            this.groupBox2.Controls.Add(this.txtFTPsFilePath);
            this.groupBox2.Location = new System.Drawing.Point(6, 6);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(593, 275);
            this.groupBox2.TabIndex = 0;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Download Information";
            // 
            // btnLogPath
            // 
            this.btnLogPath.Location = new System.Drawing.Point(418, 147);
            this.btnLogPath.Name = "btnLogPath";
            this.btnLogPath.Size = new System.Drawing.Size(31, 29);
            this.btnLogPath.TabIndex = 46;
            this.btnLogPath.Text = "...";
            this.btnLogPath.UseVisualStyleBackColor = true;
            this.btnLogPath.Click += new System.EventHandler(this.btnLogPath_Click);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(67, 150);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(102, 20);
            this.label9.TabIndex = 45;
            this.label9.Text = "Log File Path";
            // 
            // txtLogPath
            // 
            this.txtLogPath.Location = new System.Drawing.Point(175, 147);
            this.txtLogPath.Name = "txtLogPath";
            this.txtLogPath.Size = new System.Drawing.Size(227, 26);
            this.txtLogPath.TabIndex = 44;
            // 
            // btnLocalDesPath
            // 
            this.btnLocalDesPath.Location = new System.Drawing.Point(418, 112);
            this.btnLocalDesPath.Name = "btnLocalDesPath";
            this.btnLocalDesPath.Size = new System.Drawing.Size(31, 29);
            this.btnLocalDesPath.TabIndex = 42;
            this.btnLocalDesPath.Text = "...";
            this.btnLocalDesPath.UseVisualStyleBackColor = true;
            this.btnLocalDesPath.Click += new System.EventHandler(this.btnLocalDesPath_Click);
            // 
            // chkNone
            // 
            this.chkNone.AutoSize = true;
            this.chkNone.Location = new System.Drawing.Point(471, 234);
            this.chkNone.Name = "chkNone";
            this.chkNone.Size = new System.Drawing.Size(73, 24);
            this.chkNone.TabIndex = 41;
            this.chkNone.Text = "None";
            this.chkNone.UseVisualStyleBackColor = true;
            // 
            // chkPdf
            // 
            this.chkPdf.AutoSize = true;
            this.chkPdf.Location = new System.Drawing.Point(471, 204);
            this.chkPdf.Name = "chkPdf";
            this.chkPdf.Size = new System.Drawing.Size(67, 24);
            this.chkPdf.TabIndex = 40;
            this.chkPdf.Text = "PDF";
            this.chkPdf.UseVisualStyleBackColor = true;
            // 
            // chkText
            // 
            this.chkText.AutoSize = true;
            this.chkText.Location = new System.Drawing.Point(471, 175);
            this.chkText.Name = "chkText";
            this.chkText.Size = new System.Drawing.Size(65, 24);
            this.chkText.TabIndex = 39;
            this.chkText.Text = "Text";
            this.chkText.UseVisualStyleBackColor = true;
            // 
            // chkDoc
            // 
            this.chkDoc.AutoSize = true;
            this.chkDoc.Location = new System.Drawing.Point(471, 145);
            this.chkDoc.Name = "chkDoc";
            this.chkDoc.Size = new System.Drawing.Size(64, 24);
            this.chkDoc.TabIndex = 38;
            this.chkDoc.Text = "Doc";
            this.chkDoc.UseVisualStyleBackColor = true;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(467, 22);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(108, 20);
            this.label8.TabIndex = 37;
            this.label8.Text = "File Extension";
            // 
            // chkExcel
            // 
            this.chkExcel.AutoSize = true;
            this.chkExcel.Location = new System.Drawing.Point(471, 115);
            this.chkExcel.Name = "chkExcel";
            this.chkExcel.Size = new System.Drawing.Size(73, 24);
            this.chkExcel.TabIndex = 36;
            this.chkExcel.Text = "Excel";
            this.chkExcel.UseVisualStyleBackColor = true;
            // 
            // chkXml
            // 
            this.chkXml.AutoSize = true;
            this.chkXml.Location = new System.Drawing.Point(471, 85);
            this.chkXml.Name = "chkXml";
            this.chkXml.Size = new System.Drawing.Size(68, 24);
            this.chkXml.TabIndex = 35;
            this.chkXml.Text = "XML";
            this.chkXml.UseVisualStyleBackColor = true;
            // 
            // chkJson
            // 
            this.chkJson.AutoSize = true;
            this.chkJson.Location = new System.Drawing.Point(471, 55);
            this.chkJson.Name = "chkJson";
            this.chkJson.Size = new System.Drawing.Size(69, 24);
            this.chkJson.TabIndex = 34;
            this.chkJson.Text = "Json";
            this.chkJson.UseVisualStyleBackColor = true;
            // 
            // btnFTPsDownaload
            // 
            this.btnFTPsDownaload.Location = new System.Drawing.Point(26, 229);
            this.btnFTPsDownaload.Name = "btnFTPsDownaload";
            this.btnFTPsDownaload.Size = new System.Drawing.Size(143, 33);
            this.btnFTPsDownaload.TabIndex = 43;
            this.btnFTPsDownaload.Text = "Download";
            this.btnFTPsDownaload.Click += new System.EventHandler(this.btnFTPsDownaload_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(0, 118);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(169, 20);
            this.label7.TabIndex = 5;
            this.label7.Text = "Local Destination Path";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(33, 86);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(136, 20);
            this.label6.TabIndex = 4;
            this.label6.Text = "FTPs History Path";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(57, 54);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(112, 20);
            this.label5.TabIndex = 3;
            this.label5.Text = "FTPs File Path";
            // 
            // txtLocalDesPath
            // 
            this.txtLocalDesPath.Location = new System.Drawing.Point(175, 115);
            this.txtLocalDesPath.Name = "txtLocalDesPath";
            this.txtLocalDesPath.Size = new System.Drawing.Size(227, 26);
            this.txtLocalDesPath.TabIndex = 2;
            // 
            // txtFTPsHistoryPath
            // 
            this.txtFTPsHistoryPath.Location = new System.Drawing.Point(175, 83);
            this.txtFTPsHistoryPath.Name = "txtFTPsHistoryPath";
            this.txtFTPsHistoryPath.Size = new System.Drawing.Size(227, 26);
            this.txtFTPsHistoryPath.TabIndex = 1;
            // 
            // txtFTPsFilePath
            // 
            this.txtFTPsFilePath.Location = new System.Drawing.Point(175, 51);
            this.txtFTPsFilePath.Name = "txtFTPsFilePath";
            this.txtFTPsFilePath.Size = new System.Drawing.Size(227, 26);
            this.txtFTPsFilePath.TabIndex = 0;
            // 
            // FTPsFileTransferView
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(637, 562);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.txtLog);
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "FTPsFileTransferView";
            this.Text = "FTPs File Transfer";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.FTPsFileTransferView_FormClosing);
            this.Load += new System.EventHandler(this.FTPsFileTransferView_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage2.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.TextBox txtLog;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtFTPsPort;
        private System.Windows.Forms.TextBox txtFTPsPassword;
        private System.Windows.Forms.TextBox txtFTPsUsername;
        private System.Windows.Forms.TextBox txtFTPsIPAddress;
        private System.Windows.Forms.Button btnFTPsConnect;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button btnFTPsDownaload;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtLocalDesPath;
        private System.Windows.Forms.TextBox txtFTPsHistoryPath;
        private System.Windows.Forms.TextBox txtFTPsFilePath;
        private System.Windows.Forms.CheckBox chkNone;
        private System.Windows.Forms.CheckBox chkPdf;
        private System.Windows.Forms.CheckBox chkText;
        private System.Windows.Forms.CheckBox chkDoc;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.CheckBox chkExcel;
        private System.Windows.Forms.CheckBox chkXml;
        private System.Windows.Forms.CheckBox chkJson;
        private System.Windows.Forms.Button btnLocalDesPath;
        private System.Windows.Forms.Button btnLogPath;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txtLogPath;
    }
}


﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FTPsFileTransfer
{
    internal class FTPsTransferModel
    {
        public string FTPsIPAddress { get; set; }
        public string FTPsUsername { get; set; }
        public string FTPsPassword { get; set; }
        public string FTPsPort { get; set; }
        public string FTPsFilePath { get; set; }
        public string FTPsHistoryPath { get; set; }
        public string LocalDesPath { get; set; }
        public List<enumFileExtension> FileExtension { get; set; }
    }

    internal enum enumFileExtension
    {
        All = 0,
        Text = 1,
        Json = 2,
        Xml = 3
    }
}

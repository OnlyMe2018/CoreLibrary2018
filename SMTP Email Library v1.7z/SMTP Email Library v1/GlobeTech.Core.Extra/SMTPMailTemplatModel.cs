﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GlobeTech.Core.Extra
{
    public class SMTPMailTemplatModel
    {
        public string MailTo { get; set; }
        public string MailFrom { get; set; }
        public string MailCcTo { get; set; }
        public string MailBodyTemplate { get; set; }
        public string MailSubject { get; set; }
        public string MailImage1 { get; set; }
        public string MailImage2 { get; set; }
        public string MailImage3 { get; set; }
        public string MailAttatch1 { get; set; }
        public string MailAttatch2 { get; set; }
        public string MailAttatch3 { get; set; }
        public string Header { get; set; }
    }
}

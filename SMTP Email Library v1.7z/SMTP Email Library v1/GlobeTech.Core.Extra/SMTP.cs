﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.Net;
using System.Web.Mail;
using System.Net.Mail;

namespace GlobeTech.Core.Extra
{
    public class SMTP
    {
        //private SMTPModel _smtpConfig = null;
        //private SMTPMailTemplatModel _smtpMailTemplate = null;

        //private string _smtpConfigXMLPath = null;
        //private string _smtpMailTemplateXmlPath = null;

        public object data { get; private set; }

        private bool _isSuccess = false;
        public bool IsSuccess
        {
            get { return _isSuccess; }
        }

        public SMTP(SMTPModel smtpConfig, SMTPMailTemplatModel smtpMailTemplate)
        {
            try
            {
                if (smtpConfig == null || smtpMailTemplate == null)
                    throw new Exception("Configuration Model cannot be null.");

                string htmlBody = String.Format("<html>{0}<body></body></html>", smtpMailTemplate.Header);

                AlternateView avHtml = AlternateView.CreateAlternateViewFromString
                   (htmlBody, null, System.Net.Mime.MediaTypeNames.Text.Html);
                
                System.Net.Mail.MailMessage mail = new System.Net.Mail.MailMessage();
                mail.AlternateViews.Add(avHtml);

                var client = new System.Net.Mail.SmtpClient(smtpConfig.SmtpServer, smtpConfig.SmtpPort)
                {
                    UseDefaultCredentials = smtpConfig.UseDefaultCredentials,
                    DeliveryMethod = SmtpDeliveryMethod.Network,
                    EnableSsl = smtpConfig.EnableSsl,
                    Timeout = smtpConfig.Timeout,
                    Credentials = new NetworkCredential(smtpConfig.CredentialUser, smtpConfig.CredentialPassword)
                };

                string[] mailCCToAddresses = smtpMailTemplate.MailCcTo.Split(',');

                using (var message = new System.Net.Mail.MailMessage(smtpMailTemplate.MailFrom, smtpMailTemplate.MailTo)
                {
                    Subject = smtpMailTemplate.MailSubject,
                    Body = smtpMailTemplate.MailBodyTemplate,
                })
                {
                    foreach (string address in mailCCToAddresses)
                    {
                        if (!string.IsNullOrEmpty(address))
                            message.CC.Add(address);
                    }

                    if (!string.IsNullOrEmpty(smtpMailTemplate.MailAttatch1))
                    {
                        Attachment att = new Attachment(smtpMailTemplate.MailAttatch1);
                        att.ContentDisposition.Inline = true;
                        message.Attachments.Add(att);
                    }
                    if (!string.IsNullOrEmpty(smtpMailTemplate.MailAttatch2))
                    {
                        Attachment att = new Attachment(smtpMailTemplate.MailAttatch2);
                        att.ContentDisposition.Inline = true;
                        message.Attachments.Add(att);
                    }
                    if (!string.IsNullOrEmpty(smtpMailTemplate.MailAttatch3))
                    {
                        Attachment att = new Attachment(smtpMailTemplate.MailAttatch3);
                        att.ContentDisposition.Inline = true;
                        message.Attachments.Add(att);
                    }
                    message.IsBodyHtml = true;
                    client.Send(message);

                    _isSuccess = true;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}

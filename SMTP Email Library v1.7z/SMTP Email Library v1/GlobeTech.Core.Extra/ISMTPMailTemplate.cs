﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GlobeTech.Core.Extra
{
    public interface ISMTPMailTemplate
    {
        string MailTo { get; set; }
        string MailFrom { get; set; }
        string MailCcTo { get; set; }
        string MailBodyTemplate { get; set; }
        string MailSubject { get; set; }
        string MailImage1 { get; set; }
        string MailImage2 { get; set; }
        string MailImage3 { get; set; }
        string MailAttatch1 { get; set; }
        string MailAttatch2 { get; set; }
        string MailAttatch3 { get; set; }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GlobeTech.Core.Extra
{
    public interface ISMTPConfiguration
    {
        bool UseDefaultCredentials { get; set; } //fase
        bool EnableSsl { get; set; } //true
        int Timeout { get; set; } //20000
        string CredentialUser { get; set; } //onuma.tsk@gmail.com
        string CredentialPassword { get; set; } //****
        string SmtpServer { get; set; } //"smtp.gmail.com"
        int SmtpPort { get; set; } //587
    }
}

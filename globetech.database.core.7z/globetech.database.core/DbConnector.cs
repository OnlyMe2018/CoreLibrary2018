﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace globetech.database.core
{
    public class DbConnector
    {
        private string server;
        private string database;
        private string uid;
        private string password;

        private SqlConnection _sqlConn = null;
        private SqlTransaction _trans = null;

        //Constructor
        public DbConnector(string connString)
        {
            //Example: Data Source=DESKTOP-1RCB39Q;Initial Catalog=DB5726;Integrated Security=True
            if (!string.IsNullOrEmpty(connString))
                _sqlConn = new SqlConnection(connString);
        }

        //Initialize values
        private void Initialize()
        {

        }

        //open connection to database
        private bool OpenConnection()
        {
            try
            {
                if (_sqlConn != null && _sqlConn.State != System.Data.ConnectionState.Open)
                    _sqlConn.Open();
                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
            finally
            {
                //Message somthing.
            }
        }

        //Close connection
        private bool CloseConnection()
        {
            try
            {
                if (_sqlConn != null && _sqlConn.State == System.Data.ConnectionState.Open)
                    _sqlConn.Close();

                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
            finally
            {
                _sqlConn.Dispose();
                //Message somthing.
            }
        }

        public DataTable ExecuteQuery(string sql)
        {
            try
            {
                DataTable dt = null;
                OpenConnection();

                if (_sqlConn != null && _sqlConn.State == System.Data.ConnectionState.Open)
                {
                    SqlDataAdapter adapt = new SqlDataAdapter(sql, _sqlConn);
                    dt = new DataTable();
                    adapt.Fill(dt);
                }
                return dt;
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        public DataTable ExecuteQuery(SQLScriptCommand script)
        {
            try
            {
                DataTable dt = new DataTable();
                OpenConnection();

                if (_sqlConn != null && _sqlConn.State == System.Data.ConnectionState.Open)
                {
                    SqlCommand comm = new SqlCommand(script.Script, _sqlConn);

                    foreach (ParameterSet paramset in script.ParameterSets)
                        comm.Parameters.AddWithValue(paramset.ParameterKey, paramset.ParameterValue);

                    using (SqlDataReader reader = comm.ExecuteReader())
                    {
                        if (reader != null)
                            dt.Load(reader);
                    }
                }
                return dt;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public bool IsDataExist(SQLScriptCommand scriptCommand)// (string sql)
        {
            try
            {
                Int32 count = -1;

                if (_sqlConn != null && _sqlConn.State == System.Data.ConnectionState.Open)
                {
                    SqlCommand command = new SqlCommand(scriptCommand.Script, _sqlConn);
                    foreach (ParameterSet paramset in scriptCommand.ParameterSets)
                        command.Parameters.AddWithValue(paramset.ParameterKey, paramset.ParameterValue);

                    count = (Int32)command.ExecuteScalar();
                }

                return count > 0 ? true : false;
            }
            catch (Exception ex)
            {
                return false;
            }
        }

        public bool ExecuteNonQuery(SQLScriptCommand scriptCommand)
        {
            try
            {
                OpenConnection();

                if (_sqlConn != null && _sqlConn.State == System.Data.ConnectionState.Open)
                {
                    SqlCommand command = new SqlCommand(scriptCommand.Script, _sqlConn);
                    foreach (ParameterSet paramset in scriptCommand.ParameterSets)
                        command.Parameters.AddWithValue(paramset.ParameterKey, paramset.ParameterValue);

                    command.ExecuteNonQuery();
                }
                return true;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// Save data into table by pass object class.
        /// </summary>
        /// <param name="data">Object Class</param>
        /// <param name="tableName">Name of table needs to save into</param>
        /// <returns></returns>
        public bool ExecuteNonQuery(object data, string tableName)
        {
            try
            {
                DbProperities dbProp = new DbProperities();
                ExecuteNonQuery(dbProp.CreateInsertObject(data, tableName));
                return true;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public void Disconnect()
        {
            CloseConnection();
        }
    }
}

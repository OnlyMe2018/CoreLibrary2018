﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace globetech.database.core
{
    public class ParameterSet
    {
        public string ParameterKey { get; set; }
        public string ParameterValue { get; set; }
    }
}

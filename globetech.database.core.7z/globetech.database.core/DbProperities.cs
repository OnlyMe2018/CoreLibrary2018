﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace globetech.database.core
{
    internal class DbProperities
    {
        public SQLScriptCommand CreateInsertObject(object data, string tableName)
        {
            try
            {
                SQLScriptCommand insertObj = new SQLScriptCommand();
                StringBuilder columns = null;
                StringBuilder values = null;

                string column = string.Empty;
                string value = string.Empty;

                Type t = data.GetType();
                foreach (PropertyInfo proInfo in t.GetProperties())
                {
                    column = proInfo.Name;
                    value = proInfo.GetValue(data, null) != null ? proInfo.GetValue(data, null).ToString() : string.Empty;

                    if (!string.IsNullOrEmpty(column) && !string.IsNullOrEmpty(value))
                    {
                        if (columns == null || values == null)
                        {
                            columns = new StringBuilder();
                            columns.Append(column);

                            values = new StringBuilder();
                            values.Append("@").Append(column);
                        }
                        else
                        {
                            columns.Append(",").Append(column);
                            values.Append(",").Append("@").Append(column);
                        }

                        if (insertObj.ParameterSets == null)
                            insertObj.ParameterSets = new List<ParameterSet>();

                        insertObj.ParameterSets.Add(new ParameterSet { ParameterKey = "@" + column, ParameterValue = value });
                    }
                }

                insertObj.Script = String.Format("INSERT INTO {0} ({1}) VALUES({2})", tableName, columns.ToString(), values.ToString());
                return insertObj;
            }
            catch (Exception ex)
            {
                return null;
            }
        }
    }
}

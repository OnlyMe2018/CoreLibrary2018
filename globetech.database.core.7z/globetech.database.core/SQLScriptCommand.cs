﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace globetech.database.core
{
    public class SQLScriptCommand
    {
        public string Script { get; set; }
        public List<ParameterSet> ParameterSets { get; set; }
    }
}

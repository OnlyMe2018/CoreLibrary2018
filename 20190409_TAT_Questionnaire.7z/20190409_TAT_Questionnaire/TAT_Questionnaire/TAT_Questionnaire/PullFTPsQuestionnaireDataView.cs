﻿using FluentFTP;
using GlobeTech.Core.Database;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Security.Authentication;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using GlobeTech.Core.Extra;
using GlobeTech.Core.Utility;

namespace TAT_Questionnaire
{
    public partial class PullFTPsQuestionnaireDataView : Form
    {
        public PullFTPsQuestionnaireDataView()
        {
            InitializeComponent();
        }

        private static AppConfiguration _appConfig = new AppConfiguration();

        private string FileName = string.Empty;
        private string LogFile = DateTime.Now.ToString("yyyMMdd") + "_" + _appConfig.LogName + ".txt";
        private string DateNow = DateTime.Now.ToString("yyyMMdd");
        private DbConnector _conn = null;
        private StringBuilder sb = null;

        private void WriteMessageLog(string message)
        {
            if (sb == null)
                sb = new StringBuilder();

            sb.Append(Environment.NewLine + message);
        }
        private void WriteMessageLog(string message, enumMessageType type)
        {
            if (sb == null)
                sb = new StringBuilder();

            sb.Append(Environment.NewLine + "[" + DateTime.Now.ToString() + "] " + type + " : " + message);
        }

        private void btn_RunProcess_Click(object sender, EventArgs e)
        {
            bool isVersionChange = false;
            try
            {
                this.Cursor = Cursors.WaitCursor;

                WriteMessageLog("-------------------------------------------------------------------------------------");
                WriteMessageLog("-------------------------------| Start Process |-------------------------------------");
                WriteMessageLog("Application Version:" + _appConfig.Version);
                WriteMessageLog("E-form Questionnaire_TH Version:" + _appConfig.QuestionnaireVersionNo_TH);
                WriteMessageLog("E-form Questionnaire_EN Version:" + _appConfig.QuestionnaireVersionNo_EN);
                WriteMessageLog("-------------------------------------------------------------------------------------");

                FTPsDownload(_appConfig.FTPsIP, _appConfig.FTPsPort, _appConfig.FTPsUsername,
                    _appConfig.FTPsPassword, _appConfig.FTPsPath, _appConfig.FTPsHistory, _appConfig.FileExtension, _appConfig.DesPath);

                string[] files = System.IO.Directory.GetFiles(_appConfig.DesPath);
                foreach (string file in files)
                {
                    //Spite Version from Filename.
                    //config != version from file.
                    //set isVersionChange;
                    FileInfo fileInfo2 = new FileInfo(file);
                    string fileName = fileInfo2.Name.ToString();
                    string[] SplitVersion = fileName.Split('_');
                    string Version = SplitVersion[2].Replace(".json", "");

                    if ((_appConfig.QuestionnaireVersionNo_TH != Version) || (_appConfig.QuestionnaireVersionNo_EN != Version) && (isVersionChange != true))
                    {
                        isVersionChange = true;
                        //send
                        GlobeTech.Core.Utility.XmlFileManager xmlmanger = new GlobeTech.Core.Utility.XmlFileManager();
                        GlobeTech.Core.Extra.SMTPModel smtpConfig = xmlmanger.ReadXmlDataDeserializer<GlobeTech.Core.Extra.SMTPModel>(@"C:\Users\kong\Desktop\Library_SMTP_v2\SMTPModel_TAT.xml");
                        GlobeTech.Core.Extra.SMTPMailTemplat smtpMailTemplate = xmlmanger.ReadXmlDataDeserializer<GlobeTech.Core.Extra.SMTPMailTemplat>(@"C:\Users\kong\Desktop\Library_SMTP_v2\SMTPMailTemplat.xml");
                        smtpMailTemplate.MailBodyTemplate = String.Format(_appConfig.QuestionnaireVersionNo_TH, _appConfig.QuestionnaireVersionNo_EN, Version);
                        GlobeTech.Core.Extra.SMTP smtp = new GlobeTech.Core.Extra.SMTP(smtpConfig, smtpMailTemplate);
                    }

                    Queastionnaire[] results = ReadJson(file, _appConfig.FileExtension, _appConfig.FailedPath, _appConfig.SuccessPath);
                    SaveDB(results,Version);
                }

                //if(isVersionChange == true) then send mail.
                if(isVersionChange == true)
                {
                    //send mail
                }
                WriteMessageLog("Process Success", enumMessageType.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                WriteMessageLog(ex.Message, enumMessageType.Error);
            }
            finally
            {
                if (!System.IO.Directory.Exists(_appConfig.LogPath))
                    System.IO.Directory.CreateDirectory(_appConfig.LogPath);

                File.AppendAllText(System.IO.Path.Combine(_appConfig.LogPath, LogFile), sb.ToString());
                sb.Clear();

                this.Cursor = Cursors.Default;

                if(_appConfig.AutoRun.ToString() == "True")
                    this.Close();
                else
                    MessageBox.Show("Process Done!");
            }
        }

        static void OnValidateCertificate(FtpClient control, FtpSslValidationEventArgs e)
        {
            e.Accept = true;
        }
        private bool FTPsDownload(string IP, int Port, string Username, string Password, string Path, string History, string Extenstion, string Destination_local_path)
        {
            try
            {
                WriteMessageLog("FTPs Download File", enumMessageType.Information);

                FtpClient client = new FtpClient(IP, Port, Username, Password);
                client.EncryptionMode = FtpEncryptionMode.None;
                client.SslProtocols = SslProtocols.Ssl2;
                client.ValidateCertificate += new FtpSslValidation(OnValidateCertificate);
                client.Connect();

                if (client.IsConnected)
                {
                    if (!System.IO.Directory.Exists(Destination_local_path))
                        System.IO.Directory.CreateDirectory(Destination_local_path);

                    //FTPs Get File Name
                    FtpListItem[] numFilesDownloaded = client.GetListing(Path, FtpListOption.AllFiles);
                    //FTPs Get Json File
                    foreach (FtpListItem item in numFilesDownloaded)
                    {
                        FileInfo fileInfo = new FileInfo(item.Name.ToString());
                        string FileEx = fileInfo.Extension.ToString();
                        
                        if (!string.IsNullOrEmpty(FileEx))
                        {
                            //FTPs Download File
                            if (FileEx == Extenstion)
                            {
                                if (client.FileExists(History + "/" + item.Name))
                                {
                                    WriteMessageLog("Duplicate File : " + item.Name, enumMessageType.Warning);
                                    item.Name = item.Name.Replace(".json","_DUP_"+ DateNow + ".json");
                                    
                                }
                                client.DownloadFile(Destination_local_path + "/" + item.Name, item.FullName);
                            }
                            //FTPs move file
                            if (_appConfig.FTPsHistory != "")
                                client.MoveFile(item.FullName, History + "/" + item.Name);
                        }
                    }
                }
                client.Disconnect();

                return true;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        private Queastionnaire[] ReadJson(string filepath, string Extension, string Failed, string Success)
        {
            WriteMessageLog("Read Json File", enumMessageType.Information);
            Queastionnaire[] items = null;

            //Get json file
            try
            {
                if (!System.IO.Directory.Exists(_appConfig.FailedPath))
                    System.IO.Directory.CreateDirectory(_appConfig.FailedPath);

                if (!System.IO.Directory.Exists(_appConfig.SuccessPath))
                    System.IO.Directory.CreateDirectory(_appConfig.SuccessPath);

                if (Extension == System.IO.Path.GetExtension(filepath))
                {
                    using (StreamReader r = new StreamReader(filepath))
                    {
                        //read json file
                        string json = r.ReadToEnd();

                        //phase json to object
                        items = JsonConvert.DeserializeObject<Queastionnaire[]>(json);
                    }

                    System.IO.File.Move(filepath, System.IO.Path.Combine(_appConfig.SuccessPath, System.IO.Path.GetFileName(filepath)));
                    WriteMessageLog("Read " + System.IO.Path.GetFileName(filepath) + " Successed", enumMessageType.Information);

                }
                else
                {
                    System.IO.File.Move(filepath, System.IO.Path.Combine(_appConfig.FailedPath, System.IO.Path.GetFileName(filepath)));
                    WriteMessageLog("File " + System.IO.Path.GetFileName(filepath) + " Invalid Format", enumMessageType.Warning);
                }
            }
            catch (Exception ex)
            {
                System.IO.File.Move(filepath, System.IO.Path.Combine(_appConfig.FailedPath, System.IO.Path.GetFileName(filepath)));
                WriteMessageLog("Read " + System.IO.Path.GetFileName(filepath) + " Failed", enumMessageType.Error);
                WriteMessageLog(ex.Message, enumMessageType.Error);
            }

            return items;
        }
        private ParameterSet SetParameter(string key, string value)
        {
            return new ParameterSet() { ParameterKey = key, ParameterValue = value };
        }

        private bool SaveDB(Queastionnaire[] list,string Version)
        {
            try
            {
                WriteMessageLog("Save to Database", enumMessageType.Information);

                if (_conn == null)
                    _conn = new DbConnector(_appConfig.ConnectionString);

                foreach (Queastionnaire item in list)
                {
                    foreach (ResultItem i in item.result)
                    {
                        SQLScriptCommand script = new SQLScriptCommand();
                        script.Script = _appConfig.InsertScript;

                        script.ParameterSets = new List<ParameterSet>();
                        //No
                        script.ParameterSets.Add(SetParameter(_appConfig.ColumQuestionNo, i.number.Replace("question", "")));
                        //Question
                        script.ParameterSets.Add(SetParameter(_appConfig.ColumQuestion, i.question));
                        //Answer
                        script.ParameterSets.Add(SetParameter(_appConfig.ColumAnswer, i.answer));
                        //Version
                        script.ParameterSets.Add(SetParameter(_appConfig.ColumVersion, Version));
                        //Conv ID                        
                        script.ParameterSets.Add(SetParameter(_appConfig.ColumConversationID, item.utm_source != null ? item.utm_source : "NONE"));
                        //UserID
                        script.ParameterSets.Add(SetParameter(_appConfig.ColumUserID, item.utm_medium != null ? item.utm_medium : "NONE"));
                        //DateCreated
                        script.ParameterSets.Add(SetParameter(_appConfig.ColumDateCreated, item.created_at.date.ToString()));
                        //TimezoneType
                        script.ParameterSets.Add(SetParameter(_appConfig.ColumTimezoneType, item.created_at.timezone_Type.ToString()));
                        //TimesZone
                        script.ParameterSets.Add(SetParameter(_appConfig.ColumTimezone, item.created_at.timezone));
                        //TimeStamp
                        script.ParameterSets.Add(SetParameter(_appConfig.ColumTimestampRecord, DateTime.Now.ToString("yyMMdd HH:mm")));

                        //save data to database
                        _conn.ExecuteNonQuery(script);
                    }
                }
                return true;
            }
            catch (Exception ex)
            { 
                WriteMessageLog(ex.Message, enumMessageType.Error);
                return false;
                //throw ex;
            }
        }

        private void PullFTPsQuestionnaireDataView_Load(object sender, EventArgs e)
        {
            if (_appConfig.AutoRun.ToString() == "True")
            {
                this.btn_RunProcess_Click(sender, e);
            }
            else
            {
                this.txtDisplay.Text =
                "Client: TAT" + Environment.NewLine +
                "AppVersion:" + _appConfig.Version + Environment.NewLine +
                "E-form TH Version: " + _appConfig.QuestionnaireVersionNo_TH + Environment.NewLine +
                "E-form EN Version: " + _appConfig.QuestionnaireVersionNo_EN;
            }            
        }
    }
}

#region Backup by OnlyMe
//using FluentFTP;
//using GlobeTech.Core.Database;
//using Newtonsoft.Json;
//using System;
//using System.Collections.Generic;
//using System.ComponentModel;
//using System.Configuration;
//using System.Data;
//using System.Drawing;
//using System.IO;
//using System.Linq;
//using System.Security.Authentication;
//using System.Text;
//using System.Threading.Tasks;
//using System.Windows.Forms;

//namespace TAT_Questionnaire
//{
//    public partial class Form1 : Form
//    {
//        public Form1()
//        {
//            InitializeComponent();
//        }

//        //properties
//        string FTPsIP = ConfigurationManager.AppSettings["FTPsIP"].ToString();
//        string FTPsUsername = ConfigurationManager.AppSettings["FTPsUsername"].ToString();
//        string FTPsPassword = ConfigurationManager.AppSettings["FTPsPassword"].ToString();
//        int FTPsPort = Convert.ToInt32(ConfigurationManager.AppSettings["FTPsPort"]);
//        string FTPsPath = ConfigurationManager.AppSettings["FTPsPath"].ToString();
//        string FTPsHistory = ConfigurationManager.AppSettings["FTPsHistory"].ToString();
//        string DesPath = ConfigurationManager.AppSettings["DesPath"].ToString();
//        string SuccessPath = ConfigurationManager.AppSettings["SuccessPath"].ToString();
//        string FailedPath = ConfigurationManager.AppSettings["FailedPath"].ToString();
//        string FileName = string.Empty;
//        string LogFile = string.Empty;
//        string ConnectionString = ConfigurationManager.AppSettings["ConnectionString"].ToString();
//        string LogP = ConfigurationManager.AppSettings["LogPath"].ToString();
//        string activeDir = AppDomain.CurrentDomain.BaseDirectory;
//        string FileExtension = ConfigurationManager.AppSettings["FileExtension"].ToString();
//        string InsertScript = ConfigurationManager.AppSettings["InsertScript"].ToString();
//        string ColumQuestionNo = ConfigurationManager.AppSettings["ColumQuestionNo"].ToString();
//        string ColumQuestion = ConfigurationManager.AppSettings["ColumQuestion"].ToString();
//        string ColumAnswer = ConfigurationManager.AppSettings["ColumAnswer"].ToString();
//        string ColumVersion = ConfigurationManager.AppSettings["ColumVersion"].ToString();
//        string Version = ConfigurationManager.AppSettings["Version"].ToString();
//        string ColumConversationID = ConfigurationManager.AppSettings["ColumConversationID"].ToString();
//        string ColumUserID = ConfigurationManager.AppSettings["ColumUserID"].ToString();
//        string ColumDateCreated = ConfigurationManager.AppSettings["ColumDateCreated"].ToString();
//        string ColumTimezoneType = ConfigurationManager.AppSettings["ColumTimezoneType"].ToString();
//        string ColumTimezone = ConfigurationManager.AppSettings["ColumTimezone"].ToString();
//        string ColumTimestampRecord = ConfigurationManager.AppSettings["ColumTimestampRecord"].ToString();
//        string LogName = ConfigurationManager.AppSettings["LogName"].ToString();

//        StringBuilder sb = new StringBuilder();
//        private void btn_RunProcess_Click(object sender, EventArgs e)
//        {
//            string Log = System.IO.Path.Combine(activeDir, "Log" + @"\");
//            System.IO.Directory.CreateDirectory(Log);
//            string LogPath = System.IO.Path.Combine(Log, LogFile);
//            try
//            {
//                if (DateTime.Now.Hour >= 00)
//                {
//                    LogFile = LogName + DateTime.Now.ToString("MM-dd-yyyy") + ".txt";
//                }
//                else
//                {
//                    LogFile = LogName + DateTime.Now.ToString("MM-dd-yyyy") + ".txt";
//                }
//                sb.Append(Environment.NewLine + "Start PROCESS " + DateTime.Now.ToString());
//                sb.Append(Environment.NewLine + "FTPs Download File");

//                if (FTPsDownload(FTPsIP, FTPsPort, FTPsUsername, FTPsPassword, FTPsPath, FTPsHistory, FileExtension, DesPath))
//                {
//                    this.Cursor = Cursors.WaitCursor;
//                    //Write Log
//                    sb.Append(Environment.NewLine + "Read Json File");
//                    Queastionnaire[] results = ReadJson(DesPath, FileExtension, FailedPath, SuccessPath);
//                    sb.Append(Environment.NewLine + "Save to Database");

//                    foreach (Queastionnaire item in results)
//                    {
//                        SaveDB(item, InsertScript, ConnectionString);
//                    }                   

//                    MessageBox.Show("Process Success");
//                    sb.Append(Environment.NewLine + "Process Sucess");
//                    sb.Append(Environment.NewLine + "*****************");
//                    File.AppendAllText(LogPath + LogFile, sb.ToString());
//                    sb.Clear();
//                }
//            }
//            catch (Exception ex)
//            {
//                MessageBox.Show(ex.Message);
//                sb.Append(Environment.NewLine + ex.ToString());
//                sb.Append(Environment.NewLine + "*****************");
//                File.AppendAllText(LogPath + LogFile, sb.ToString());
//                sb.Clear();
//                //write Log
//            }
//            finally
//            {
//                this.Cursor = Cursors.Default;

//            }
//        }
//        static void OnValidateCertificate(FtpClient control, FtpSslValidationEventArgs e)
//        {
//            e.Accept = true;
//        }
//        public bool FTPsDownload(string IP, int Port, string Username, string Password, string Path, string History, string Extenstion, string Des)
//        {
//            try
//            {
//                bool success;
//                FtpClient client = new FtpClient(IP, Port, Username, Password);
//                client.EncryptionMode = FtpEncryptionMode.None;
//                client.SslProtocols = SslProtocols.Ssl2;
//                client.ValidateCertificate += new FtpSslValidation(OnValidateCertificate);
//                client.Connect();
//                success = client.IsConnected;
//                if (success == true)
//                {
//                    //FTPs Get File Name
//                    FtpListItem[] numFilesDownloaded = client.GetListing(Path, FtpListOption.AllFiles);
//                    //FTPs Get Json File
//                    foreach (FtpListItem item in numFilesDownloaded)
//                    {
//                        FileInfo fileInfo = new FileInfo(item.Name.ToString());
//                        string FileEx = fileInfo.Extension.ToString();
//                        //FTPs Download File
//                        if (FileEx == Extenstion)
//                        {
//                            client.DownloadFile(Des + "/" + item.Name, item.FullName);
//                        }
//                        //FTPs move file
//                        if (FTPsHistory != "")
//                        {
//                            client.MoveFile(item.FullName, History + "/" + item.Name);

//                        }
//                    }
//                }
//                client.Disconnect();
//                return success;
//            }
//            catch (Exception ex)
//            {
//                throw ex;
//            }
//        }
//        public Queastionnaire[] ReadJson(string Des, string Extension, string Failed, string Success)
//        {
//            try
//            {
//                Queastionnaire[] items = null;

//                string[] files = System.IO.Directory.GetFiles(Des);
//                foreach (string s in files)
//                {
//                    //Get json file
//                    string JsonFile = System.IO.Path.GetFileName(s);
//                    string FileEx = System.IO.Path.GetExtension(s);
//                    if (FileEx == Extension)
//                    {
//                        //read json file
//                        try
//                        {
//                            using (StreamReader r = new StreamReader(DesPath + @"\" + JsonFile))
//                            {
//                                string json = r.ReadToEnd();
//                                //phase json to object
//                                items = JsonConvert.DeserializeObject<Queastionnaire[]>(json);
//                            }
//                            System.IO.File.Move(DesPath + @"\" + JsonFile, Success + @"\" + JsonFile);
//                            sb.Append(Environment.NewLine + "Read Success : " + JsonFile);
//                        }
//                        catch (Exception ex)
//                        {
//                            System.IO.File.Move(DesPath + @"\" + JsonFile, Failed + @"\" + JsonFile);
//                            sb.Append(Environment.NewLine + "Read Failed : " + JsonFile);
//                        }
//                    }
//                }
//                return items;
//            }
//            catch (Exception ex)
//            {
//                throw ex;
//            }
//        }
//        public bool SaveDB(Queastionnaire[] list, string Insert, string Connection)
//        {            
//            DbConnector conn = new DbConnector(Connection);
//            try
//            {
//                foreach (Queastionnaire item in list)
//                {
//                    foreach (ResultItem i in item.result)
//                    {
//                        //save data to database
//                        SQLScriptCommand script = new SQLScriptCommand();
//                        script.Script = Insert;
//                        script.ParameterSets = new List<ParameterSet>();
//                        ParameterSet param = new ParameterSet();
//                        //Question No Column
//                        param.ParameterKey = ColumQuestionNo;
//                        param.ParameterValue = i.number.Replace("question", "");
//                        script.ParameterSets.Add(param);
//                        //Question
//                        param = new ParameterSet();
//                        param.ParameterKey = ColumQuestion;
//                        param.ParameterValue = i.question;
//                        script.ParameterSets.Add(param);
//                        //Answer
//                        param = new ParameterSet();
//                        param.ParameterKey = ColumAnswer;
//                        param.ParameterValue = i.answer;
//                        script.ParameterSets.Add(param);
//                        //Version
//                        param = new ParameterSet();
//                        param.ParameterKey = ColumVersion;
//                        param.ParameterValue = Version;
//                        script.ParameterSets.Add(param);
//                        //ConID
//                        param = new ParameterSet();
//                        param.ParameterKey = ColumConversationID;
//                        param.ParameterValue = item.utm_source;
//                        script.ParameterSets.Add(param);
//                        //UserID
//                        param = new ParameterSet();
//                        param.ParameterKey = ColumUserID;
//                        param.ParameterValue = item.utm_medium;
//                        script.ParameterSets.Add(param);
//                        //DateCreated
//                        param = new ParameterSet();
//                        param.ParameterKey = ColumDateCreated;
//                        param.ParameterValue = item.created_at.date.ToString();
//                        script.ParameterSets.Add(param);
//                        //TimezoneType
//                        param = new ParameterSet();
//                        param.ParameterKey = ColumTimezoneType;
//                        param.ParameterValue = item.created_at.timezone_Type.ToString();
//                        script.ParameterSets.Add(param);
//                        //TimesZone
//                        param = new ParameterSet();
//                        param.ParameterKey = ColumTimezone;
//                        param.ParameterValue = item.created_at.timezone;
//                        script.ParameterSets.Add(param);
//                        //TimeStamp
//                        param = new ParameterSet();
//                        param.ParameterKey = ColumTimestampRecord;
//                        param.ParameterValue = DateTime.Now.ToString("yyMMdd HH:mm");
//                        script.ParameterSets.Add(param);
//                        conn.ExecuteNonQuery(script);
//                    }
//                }
//                return true;
//            }
//            catch(Exception ex)
//            {
//                throw ex;
//            }
//        }
//        public bool SaveDB(Queastionnaire list, string Insert, string Connection)
//        {
//            DbConnector conn = new DbConnector(Connection);
//            try
//            {
//                foreach (Queastionnaire item in list)
//                {
//                    foreach (ResultItem i in item.result)
//                    {
//                        //save data to database
//                        SQLScriptCommand script = new SQLScriptCommand();
//                        script.Script = Insert;
//                        script.ParameterSets = new List<ParameterSet>();
//                        ParameterSet param = new ParameterSet();
//                        //Question No Column
//                        param.ParameterKey = ColumQuestionNo;
//                        param.ParameterValue = i.number.Replace("question", "");
//                        script.ParameterSets.Add(param);
//                        //Question
//                        param = new ParameterSet();
//                        param.ParameterKey = ColumQuestion;
//                        param.ParameterValue = i.question;
//                        script.ParameterSets.Add(param);
//                        //Answer
//                        param = new ParameterSet();
//                        param.ParameterKey = ColumAnswer;
//                        param.ParameterValue = i.answer;
//                        script.ParameterSets.Add(param);
//                        //Version
//                        param = new ParameterSet();
//                        param.ParameterKey = ColumVersion;
//                        param.ParameterValue = Version;
//                        script.ParameterSets.Add(param);
//                        //ConID
//                        param = new ParameterSet();
//                        param.ParameterKey = ColumConversationID;
//                        param.ParameterValue = item.utm_source;
//                        script.ParameterSets.Add(param);
//                        //UserID
//                        param = new ParameterSet();
//                        param.ParameterKey = ColumUserID;
//                        param.ParameterValue = item.utm_medium;
//                        script.ParameterSets.Add(param);
//                        //DateCreated
//                        param = new ParameterSet();
//                        param.ParameterKey = ColumDateCreated;
//                        param.ParameterValue = item.created_at.date.ToString();
//                        script.ParameterSets.Add(param);
//                        //TimezoneType
//                        param = new ParameterSet();
//                        param.ParameterKey = ColumTimezoneType;
//                        param.ParameterValue = item.created_at.timezone_Type.ToString();
//                        script.ParameterSets.Add(param);
//                        //TimesZone
//                        param = new ParameterSet();
//                        param.ParameterKey = ColumTimezone;
//                        param.ParameterValue = item.created_at.timezone;
//                        script.ParameterSets.Add(param);
//                        //TimeStamp
//                        param = new ParameterSet();
//                        param.ParameterKey = ColumTimestampRecord;
//                        param.ParameterValue = DateTime.Now.ToString("yyMMdd HH:mm");
//                        script.ParameterSets.Add(param);
//                        conn.ExecuteNonQuery(script);
//                    }
//                }
//                return true;
//            }
//            catch (Exception ex)
//            {
//                throw ex;
//            }
//        }
//    }
//}
#endregion Backup by OnlyMe
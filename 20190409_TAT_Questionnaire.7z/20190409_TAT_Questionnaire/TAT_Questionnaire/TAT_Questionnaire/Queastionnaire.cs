﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TAT_Questionnaire
{
    public class Queastionnaire
    {
        public ResultItem[] result { get; set; }
        public string utm_source { get; set; }
        public string utm_medium { get; set; }
        public string utm_campaign { get; set; }
        public string utm_term { get; set; }
        public string utm_content { get; set; }
        public string media { get; set; }
        public CreateItem created_at { get; set; }
        public int Version { get; set; }
        public string GetVersion { get; set; }
        //public int QuestionnaireVersionNo  { get; set; }
    }
    public class ResultItem
    {
        public string number { get; set; }
        public string question { get; set; }
        public string answer { get; set; }
    }
    public class CreateItem
    {
        public DateTime date { get; set; }
        public int timezone_Type { get; set; }
        public string timezone { get; set; }
    }
}

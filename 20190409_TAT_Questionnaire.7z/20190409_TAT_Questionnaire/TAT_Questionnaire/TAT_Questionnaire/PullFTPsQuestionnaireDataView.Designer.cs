﻿namespace TAT_Questionnaire
{
    partial class PullFTPsQuestionnaireDataView
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_RunProcess = new System.Windows.Forms.Button();
            this.txtDisplay = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // btn_RunProcess
            // 
            this.btn_RunProcess.Location = new System.Drawing.Point(332, 27);
            this.btn_RunProcess.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btn_RunProcess.Name = "btn_RunProcess";
            this.btn_RunProcess.Size = new System.Drawing.Size(89, 36);
            this.btn_RunProcess.TabIndex = 0;
            this.btn_RunProcess.Text = "RUN";
            this.btn_RunProcess.UseVisualStyleBackColor = true;
            this.btn_RunProcess.Click += new System.EventHandler(this.btn_RunProcess_Click);
            // 
            // txtDisplay
            // 
            this.txtDisplay.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.txtDisplay.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtDisplay.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.txtDisplay.Location = new System.Drawing.Point(24, 27);
            this.txtDisplay.Multiline = true;
            this.txtDisplay.Name = "txtDisplay";
            this.txtDisplay.ReadOnly = true;
            this.txtDisplay.Size = new System.Drawing.Size(290, 109);
            this.txtDisplay.TabIndex = 2;
            // 
            // PullFTPsQuestionnaireDataView
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(438, 158);
            this.Controls.Add(this.txtDisplay);
            this.Controls.Add(this.btn_RunProcess);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.MaximizeBox = false;
            this.Name = "PullFTPsQuestionnaireDataView";
            this.Text = "TAT: Pull Questionnaire Result";
            this.Load += new System.EventHandler(this.PullFTPsQuestionnaireDataView_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_RunProcess;
        private System.Windows.Forms.TextBox txtDisplay;
    }
}


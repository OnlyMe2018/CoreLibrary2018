﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TAT_Questionnaire
{
    public class AppConfiguration
    {
        //properties
        public string FTPsIP { get { return ConfigurationManager.AppSettings["FTPsIP"].ToString(); } }
        public string FTPsUsername { get { return ConfigurationManager.AppSettings["FTPsUsername"].ToString(); } }
        public string FTPsPassword { get { return ConfigurationManager.AppSettings["FTPsPassword"].ToString(); } }
        public int FTPsPort { get { return Convert.ToInt32(ConfigurationManager.AppSettings["FTPsPort"]); } }
        public string FTPsPath { get { return ConfigurationManager.AppSettings["FTPsPath"].ToString(); } }
        public string FTPsHistory { get { return ConfigurationManager.AppSettings["FTPsHistory"].ToString(); } }
        public string DesPath { get { return ConfigurationManager.AppSettings["DesPath"].ToString(); } }
        public string SuccessPath { get { return ConfigurationManager.AppSettings["SuccessPath"].ToString(); } }
        public string FailedPath { get { return ConfigurationManager.AppSettings["FailedPath"].ToString(); } }
        public string ConnectionString { get { return ConfigurationManager.AppSettings["ConnectionString"].ToString(); } }
        public string LogPath { get { return ConfigurationManager.AppSettings["LogPath"].ToString(); } }
        public string ActiveDir { get { return AppDomain.CurrentDomain.BaseDirectory; } }
        public string FileExtension { get { return ConfigurationManager.AppSettings["FileExtension"].ToString(); } }
        public string InsertScript { get { return ConfigurationManager.AppSettings["InsertScript"].ToString(); } }
        public string ColumQuestionNo { get { return ConfigurationManager.AppSettings["ColumQuestionNo"].ToString(); } }
        public string ColumQuestion { get { return ConfigurationManager.AppSettings["ColumQuestion"].ToString(); } }
        public string ColumAnswer { get { return ConfigurationManager.AppSettings["ColumAnswer"].ToString(); } }
        public string ColumVersion { get { return ConfigurationManager.AppSettings["ColumVersion"].ToString(); } }
        public string Version { get { return ConfigurationManager.AppSettings["Version"].ToString(); } }
        public string ColumConversationID { get { return ConfigurationManager.AppSettings["ColumConversationID"].ToString(); } }
        public string ColumUserID { get { return ConfigurationManager.AppSettings["ColumUserID"].ToString(); } }
        public string ColumDateCreated { get { return ConfigurationManager.AppSettings["ColumDateCreated"].ToString(); } }
        public string ColumTimezoneType { get { return ConfigurationManager.AppSettings["ColumTimezoneType"].ToString(); } }
        public string ColumTimezone { get { return ConfigurationManager.AppSettings["ColumTimezone"].ToString(); } }
        public string ColumTimestampRecord { get { return ConfigurationManager.AppSettings["ColumTimestampRecord"].ToString(); } }
        public string LogName { get { return ConfigurationManager.AppSettings["LogName"].ToString(); } }
        public string QuestionnaireVersionNo_TH { get { return ConfigurationManager.AppSettings["QuestionnaireVersionNo_TH"].ToString(); } }
        public string QuestionnaireVersionNo_EN { get { return ConfigurationManager.AppSettings["QuestionnaireVersionNo_EN"].ToString(); } }
        public string AutoRun { get { return ConfigurationManager.AppSettings["AutoRun"].ToString(); } }
    }

    public enum enumMessageType
    {       
        Error = 0,
        Information = 1,
        Warning = 2
    }
}
